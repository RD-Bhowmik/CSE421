import socket

def start_client():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    host = 'localhost'
    port = 65535
    
    try:
        client_socket.connect((host, port))
        print(f"Connected to Salary Calculator Server at {host}:{port}")
        print("Enter the number of hours worked to calculate salary.")
        print("Salary Rules:")
        print("- ≤40 hours: Tk 200 per hour")
        print("- >40 hours: Tk 8000 + Tk 300 for each hour over 40")
        print("Type 'quit' to exit.")
        print("-" * 60)
        
        while True:
            hours_input = input("Enter hours worked: ")
            
            if hours_input.lower() == 'quit':
                client_socket.send(hours_input.encode('utf-8'))
                print("Disconnecting from server...")
                break
            
            try:
                hours = float(hours_input)
                if hours < 0:
                    print("Error: Hours cannot be negative. Please try again.")
                    continue
                
                client_socket.send(hours_input.encode('utf-8'))
                
                response = client_socket.recv(1024).decode('utf-8')
                print(f"Calculated salary: {response}")
                print("-" * 60)
                
            except ValueError:
                print("Error: Please enter a valid number. Try again.")
        
    except Exception as e:
        print(f"Error: {e}")
    finally:
        client_socket.close()
        print("Client disconnected.")

if __name__ == "__main__":
    start_client()