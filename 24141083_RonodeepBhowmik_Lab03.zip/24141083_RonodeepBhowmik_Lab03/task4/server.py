import socket

def calculate_salary(hours):
    if hours <= 40:
        salary = hours * 200
    else:
        overtime_hours = hours - 40
        salary = 8000 + (overtime_hours * 300)
    return salary

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    host = 'localhost'
    port = 65535
    
    try:
        server_socket.bind((host, port))
        server_socket.listen(1)
        
        print(f"Salary Calculator Server started on {host}:{port}")
        print("Waiting for client connection...")
        
        client_socket, client_address = server_socket.accept()
        print(f"Connection established with {client_address}")
        
        while True:
            data = client_socket.recv(1024).decode('utf-8')
            
            if not data or data.lower() == 'quit':
                print("Client disconnected.")
                break
            
            try:
                hours_worked = float(data)
                print(f"Received hours worked: {hours_worked}")
                
                salary = calculate_salary(hours_worked)
                print(f"Calculated salary: Tk {salary}")
                
                response = f"Tk {salary}"
                client_socket.send(response.encode('utf-8'))
                print(f"Sent salary to client: {response}")
                print("-" * 40)
                
            except ValueError:
                error_message = "Invalid input. Please enter a valid number of hours."
                client_socket.send(error_message.encode('utf-8'))
                print(f"Sent error message: {error_message}")
        
        client_socket.close()
        
    except Exception as e:
        print(f"Error: {e}")
    finally:
        server_socket.close()
        print("Server closed.")

if __name__ == "__main__":
    start_server()