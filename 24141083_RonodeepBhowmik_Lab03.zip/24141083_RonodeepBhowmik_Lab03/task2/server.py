import socket

def count_vowels(message):
    """Count the number of vowels in a message"""
    vowels = "aeiouAEIOU"
    count = 0
    for char in message:
        if char in vowels:
            count += 1
    return count

def get_vowel_response(vowel_count):
    if vowel_count == 0:
        return "Not enough vowels"
    elif vowel_count <= 2:
        return "Enough vowels I guess"
    else:
        return "Too many vowels"

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    host = 'localhost'
    port = 65535 
    try:
        server_socket.bind((host, port))
        
        server_socket.listen(1)
        
        print(f"Vowel Counter Server started on {host}:{port}")
        print("Waiting for client connection...")
        
        client_socket, client_address = server_socket.accept()
        print(f"Connection established with {client_address}")
        
        while True:
            data = client_socket.recv(1024).decode('utf-8')
            
            if not data or data.lower() == 'quit':
                print("Client disconnected.")
                break
            
            print(f"Received message: '{data}'")
            vowel_count = count_vowels(data)
            print(f"Vowels found: {vowel_count}")
            response = get_vowel_response(vowel_count)
            print(f"Sending response: '{response}'")
            client_socket.send(response.encode('utf-8'))
            print("-" * 40)
        
        client_socket.close()
        
    except Exception as e:
        print(f"Error: {e}")
    finally:
        server_socket.close()
        print("Server closed.")

if __name__ == "__main__":
    start_server()