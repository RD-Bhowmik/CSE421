import socket

def start_client():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    host = 'localhost'
    port = 65535
    
    try:
        client_socket.connect((host, port))
        print(f"Connected to Vowel Counter Server at {host}:{port}")
        print("You can send messages to the server. Type 'quit' to exit.")
        print("-" * 50)
        
        while True:
            message = input("Enter a message: ")
            
            if message.lower() == 'quit':
                client_socket.send(message.encode('utf-8'))
                print("Disconnecting from server...")
                break
            client_socket.send(message.encode('utf-8'))
            response = client_socket.recv(1024).decode('utf-8')
            print(f"Server response: {response}")
            print("-" * 50)
        
    except Exception as e:
        print(f"Error: {e}")
    finally:
        client_socket.close()
        print("Client disconnected.")

if __name__ == "__main__":
    start_client()