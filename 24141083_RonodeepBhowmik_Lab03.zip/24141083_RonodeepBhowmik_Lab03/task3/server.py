import socket
import threading

def count_vowels(message):
    vowels = "aeiouAEIOU"
    count = 0
    for char in message:
        if char in vowels:
            count += 1
    return count

def get_vowel_response(vowel_count):
    if vowel_count == 0:
        return "Not enough vowels"
    elif vowel_count <= 2:
        return "Enough vowels I guess"
    else:
        return "Too many vowels"

def handle_client(client_socket, client_address):
    print(f"New client connected: {client_address}")
    
    try:
        while True:
            data = client_socket.recv(1024).decode('utf-8')
            
            if not data or data.lower() == 'quit':
                print(f"Client {client_address} disconnected.")
                break
            
            print(f"[{client_address}] Received message: '{data}'")
            
            vowel_count = count_vowels(data)
            print(f"[{client_address}] Vowels found: {vowel_count}")
            
            response = get_vowel_response(vowel_count)
            print(f"[{client_address}] Sending response: '{response}'")
            
            client_socket.send(response.encode('utf-8'))
            
    except Exception as e:
        print(f"Error handling client {client_address}: {e}")
    finally:
        client_socket.close()
        print(f"Connection with {client_address} closed.")

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    
    host = 'localhost'
    port = 65535
    
    try:
        server_socket.bind((host, port))
        server_socket.listen(5)
        
        print(f"Multi-threaded Vowel Counter Server started on {host}:{port}")
        print("Server can handle multiple clients simultaneously...")
        print("Waiting for client connections...")
        
        while True:
            client_socket, client_address = server_socket.accept()
            client_thread = threading.Thread(
                target=handle_client, 
                args=(client_socket, client_address)
            )
            client_thread.daemon = True  
            client_thread.start()
            
    except KeyboardInterrupt:
        print("\nServer shutting down...")
    except Exception as e:
        print(f"Server error: {e}")
    finally:
        server_socket.close()
        print("Server closed.")

if __name__ == "__main__":
    start_server()